﻿Imports System.Data.OleDb

Public Class Form1
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        Dim con As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\Database11.accdb")
        Dim cmd As New OleDbCommand("SELECT * FROM Users WHERE USERNAME = '" & txtUser.Text & "' AND [PASSWORD] = '" & txtPass.Text & "' ", con)

        con.Open()

        Dim sdr As OleDbDataReader = cmd.ExecuteReader()
        If (sdr.Read() = True) Then
            Dim user As String = sdr("USERNAME")
            Dim pass As String = sdr("PASSWORD")
            MessageBox.Show("Login Successful.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Form2.Show()
            Me.Hide()
        ElseIf txtUser.Text = Nothing Or txtPass.Text = Nothing Then
            MessageBox.Show("Please enter value for Username & Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            MessageBox.Show("Wrong Input on Username or Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database11DataSet.Users' table. You can move, or remove it, as needed.
        Me.UsersTableAdapter.Fill(Me.Database11DataSet.Users)

    End Sub
End Class