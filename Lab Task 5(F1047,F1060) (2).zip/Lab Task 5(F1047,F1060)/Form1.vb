﻿Imports System.Text.RegularExpressions

Public Class Form1
    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        ' Validate email address using regular expressions
        Dim emailPattern As String = "^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$"
        Dim emailRegex As New Regex(emailPattern)

        If txtEmail.Text.Trim() = "" OrElse Not emailRegex.IsMatch(txtEmail.Text.Trim()) Then
            MessageBox.Show("Please enter a valid email address.")
            Return
        End If

        ' Validate password format
        Dim password As String = txtPassword.Text.Trim()

        If password = "" OrElse password.Length <> 8 OrElse Not password.Any(Function(c) Char.IsLetter(c)) OrElse Not password.Any(Function(c) Char.IsDigit(c)) Then
            MessageBox.Show("Password must be 8 characters long and contain at least one letter and one number.")
            Return
        End If

        ' Check if both email address and password are not blank
        If txtEmail.Text.Trim() = "" OrElse txtPassword.Text.Trim() = "" Then
            MessageBox.Show("Email address and password cannot be blank.")
            Return
        End If

        ' Display registration successful message
        MessageBox.Show("Registration successful!")

        ' Redirect to Form2
        Me.Hide()
        Dim form2 As New Form2()
        form2.Show()
    End Sub
End Class
