﻿Public Class Form2
    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        ' Check if any input fields are blank
        If txtName.Text.Trim() = "" OrElse txtAddress.Text.Trim() = "" OrElse txtPhone.Text.Trim() = "" OrElse cbFood.SelectedItem Is Nothing OrElse txtQuantity.Text.Trim() = "" Then
            MessageBox.Show("All fields must be filled out.")
            Return
        End If

        ' Convert name and address to uppercase
        Dim nameUpperCase As String = txtName.Text.Trim().ToUpper()
        Dim addressUpperCase As String = txtAddress.Text.Trim().ToUpper()

        ' Calculate total cost based on selected food item and quantity
        Dim costPerItem As Double = 0.0
        Select Case cbFood.SelectedItem.ToString().ToLower()
            Case "pasta"
                costPerItem = 15.0 ' RM15 for pasta
            Case "burger"
                costPerItem = 5.0 ' RM5 for burger
            Case "pizza"
                costPerItem = 10.0 ' RM10 for pizza
            Case Else
                MessageBox.Show("Invalid food selection.")
                Return
        End Select

        Dim quantity As Integer
        If Integer.TryParse(txtQuantity.Text.Trim(), quantity) Then
            Dim totalCost As Double = quantity * costPerItem
            If quantity > 5 Then
                totalCost *= 0.9 ' Apply 10% discount
            End If

            ' Display order details in messagebox
            Dim message As String = "Name: " & nameUpperCase & vbCrLf &
                                    "Address: " & addressUpperCase & vbCrLf &
                                    "Phone: " & txtPhone.Text.Trim() & vbCrLf &
                                    "Food: " & cbFood.SelectedItem.ToString() & vbCrLf &
                                    "Quantity: " & quantity.ToString() & vbCrLf &
                                    "Total Cost: RM" & totalCost.ToString("0.00")
            MessageBox.Show(message)
        Else
            MessageBox.Show("Quantity must be a valid integer.")
        End If
    End Sub
End Class