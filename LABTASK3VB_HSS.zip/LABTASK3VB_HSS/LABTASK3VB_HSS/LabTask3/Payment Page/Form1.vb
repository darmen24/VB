﻿Public Class Payment_Page
    Private Sub Payment_Page_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
