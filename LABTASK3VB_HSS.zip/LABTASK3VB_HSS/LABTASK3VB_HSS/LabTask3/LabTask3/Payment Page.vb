﻿Imports System.Net

Public Class Payment_Page
    Public Property SelectedItems As New List(Of Cookie) ' Change the type to Cookie
    Private Sub Payment_Page_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Display selected items with quantities in ListBox
        For Each cookie As Cookie In SelectedItems
            ListBox1.Items.Add(cookie.Name & " (Quantity: " & cookie.Quantity & ")")
        Next
    End Sub

    Private Sub btnConfirm_Click(sender As Object, e As EventArgs) Handles btnConfirm.Click
        ' Calculate total cost of the order
        Dim totalCost As Double = CalculateTotalCost()

        ' Display order confirmation message
        DisplayOrderConfirmation(totalCost)
    End Sub

    Private Function CalculateTotalCost() As Double
        Dim total As Double = 0.0
        For Each cookie As Cookie In SelectedItems
            total += cookie.CalculateSubtotal()
        Next
        Return total
    End Function

    Private Sub DisplayOrderConfirmation(totalCost As Double)
        Dim message As String = "Order Confirmation:" & vbCrLf
        For Each cookie As Cookie In SelectedItems
            message &= cookie.Name & ": Quantity " & cookie.Quantity & ", Subtotal: RM " & cookie.CalculateSubtotal().ToString("F2") & vbCrLf
        Next
        message &= "Total Cost: RM " & totalCost.ToString("F2") & vbCrLf & "Proceed with your payment?"

        Dim result As MsgBoxResult = MsgBox(message, vbYesNo + vbQuestion, "Payment Confirmation")

        If result = MsgBoxResult.Yes Then
            MsgBox("Your payment was successful.", vbOKOnly + vbInformation, "Payment Successful")
        End If
    End Sub

    Private Sub btnHome_Click(sender As Object, e As EventArgs) Handles btnHome.Click
        ' Hide the PaymentPage form
        Me.Hide()

        ' Show the previously opened form (assuming it's Form1)
        Form1.Show()
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub
End Class
