﻿Imports System.Net

Public Class Form1
    Private Sub btnPay_Click(sender As Object, e As EventArgs) Handles btnPay.Click
        ' Create an instance of PaymentPage form
        Dim paymentForm As New Payment_Page()

        ' Pass selected items as Cookie objects to PaymentPage
        paymentForm.SelectedItems.AddRange(GetSelectedCookiesWithQuantities())

        ' Display PaymentPage form
        paymentForm.ShowDialog()
    End Sub

    Private Function GetSelectedCookiesWithQuantities() As List(Of Cookie)
        Dim selectedCookies As New List(Of Cookie)

        ' Create instances of Cookie with the required arguments
        If chkb1.Checked Then
            Dim chocoChipCookie As New Cookie("Choco Chip", 30.0, Convert.ToInt32(n1.Value))
            selectedCookies.Add(chocoChipCookie)
        End If
        If chkb2.Checked Then
            Dim macaronCookie As New Cookie("Macaron", 40.0, Convert.ToInt32(n2.Value))
            selectedCookies.Add(macaronCookie)
        End If
        If chkb3.Checked Then
            Dim PeanutButterCookie As New Cookie("Peanut Butter", 35.0, Convert.ToInt32(n3.Value))
            selectedCookies.Add(PeanutButterCookie)
        End If
        If chkb4.Checked Then
            Dim AlmondLondonCookie As New Cookie("Almond London", 25.0, Convert.ToInt32(n4.Value))
            selectedCookies.Add(AlmondLondonCookie)
        End If
        Return selectedCookies
    End Function

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Dim result As MsgBoxResult = MsgBox("Done with your orders,are you sure that you want to exit your order?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "Confirmation")
        If result = MsgBoxResult.Yes Then
            ' If the user clicks Yes, close the form
            Me.Close()
        Else
            ' If the user clicks No, do nothing (continue with the current form)
        End If
    End Sub

    Private Sub btnTotal_Click(sender As Object, e As EventArgs) Handles btnTotal.Click
        ' This part remains the same
        Dim ChocChipPrice As Double = 30.0
        Dim MaraconPrice As Double = 40.0
        Dim PeanutPrice As Double = 35.0
        Dim AlmondPrice As Double = 25.0
        Dim total As Double = 0.00

        If chkb1.Checked Then
            Dim AlmondQuantity As Integer = Convert.ToInt32(n1.Value)
            total += ChocChipPrice * AlmondQuantity
        End If
        If chkb2.Checked Then
            Dim shortQuantity As Integer = Convert.ToInt32(n2.Value)
            total += MaraconPrice * shortQuantity
        End If
        If chkb3.Checked Then
            Dim tartQuantity As Integer = Convert.ToInt32(n3.Value)
            total += PeanutPrice * tartQuantity
        End If
        If chkb4.Checked Then
            Dim cornflakesQuantity As Integer = Convert.ToInt32(n4.Value)
            total += AlmondPrice * cornflakesQuantity
        End If
        lblPrice.Text = total.ToString("F2")
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

    Private Sub lblPrice_Click(sender As Object, e As EventArgs) Handles lblPrice.Click

    End Sub
End Class