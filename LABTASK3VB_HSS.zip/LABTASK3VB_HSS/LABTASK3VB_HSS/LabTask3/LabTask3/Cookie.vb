﻿Public Class Cookie
    Public Property Name As String
    Public Property Price As Double
    Public Property Quantity As Integer

    ' Constructor to initialize properties
    Public Sub New(name As String, price As Double, quantity As Integer)
        Me.Name = name
        Me.Price = price
        Me.Quantity = quantity
    End Sub

    ' Method to calculate subtotal price for this type of cookie
    Public Function CalculateSubtotal() As Double
        Return Price * Quantity
    End Function

End Class
