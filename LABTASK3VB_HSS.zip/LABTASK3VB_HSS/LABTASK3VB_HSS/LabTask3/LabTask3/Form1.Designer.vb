﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        lblTitle = New Label()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        PictureBox4 = New PictureBox()
        Label5 = New Label()
        chkb1 = New CheckBox()
        GroupBox1 = New GroupBox()
        n4 = New NumericUpDown()
        n3 = New NumericUpDown()
        n2 = New NumericUpDown()
        n1 = New NumericUpDown()
        chkb4 = New CheckBox()
        chkb3 = New CheckBox()
        chkb2 = New CheckBox()
        btnPay = New Button()
        btnExit = New Button()
        lblPrice = New Label()
        btnTotal = New Button()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        GroupBox1.SuspendLayout()
        CType(n4, ComponentModel.ISupportInitialize).BeginInit()
        CType(n3, ComponentModel.ISupportInitialize).BeginInit()
        CType(n2, ComponentModel.ISupportInitialize).BeginInit()
        CType(n1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.BackColor = Color.Thistle
        lblTitle.BorderStyle = BorderStyle.FixedSingle
        lblTitle.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblTitle.Location = New Point(253, 29)
        lblTitle.Margin = New Padding(2, 0, 2, 0)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(244, 23)
        lblTitle.TabIndex = 0
        lblTitle.Text = "Raya Cookies Ordering System"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(46, 70)
        PictureBox1.Margin = New Padding(2)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(148, 94)
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackgroundImage = CType(resources.GetObject("PictureBox2.BackgroundImage"), Image)
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(46, 222)
        PictureBox2.Margin = New Padding(2)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(139, 94)
        PictureBox2.TabIndex = 2
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackgroundImage = CType(resources.GetObject("PictureBox3.BackgroundImage"), Image)
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(267, 70)
        PictureBox3.Margin = New Padding(2)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(130, 94)
        PictureBox3.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox3.TabIndex = 3
        PictureBox3.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.HotPink
        Label2.Font = New Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(77, 170)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(82, 19)
        Label2.TabIndex = 4
        Label2.Text = "Choco Chip"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.HotPink
        Label3.Font = New Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(77, 330)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(64, 19)
        Label3.TabIndex = 5
        Label3.Text = "Macaron"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.HotPink
        Label4.Font = New Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(292, 170)
        Label4.Margin = New Padding(2, 0, 2, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(94, 19)
        Label4.TabIndex = 6
        Label4.Text = "Peanut Butter"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), Image)
        PictureBox4.Location = New Point(275, 219)
        PictureBox4.Margin = New Padding(2)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(122, 97)
        PictureBox4.TabIndex = 7
        PictureBox4.TabStop = False
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.HotPink
        Label5.Font = New Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(278, 330)
        Label5.Margin = New Padding(2, 0, 2, 0)
        Label5.Name = "Label5"
        Label5.Size = New Size(109, 19)
        Label5.TabIndex = 8
        Label5.Text = "Almond London"
        ' 
        ' chkb1
        ' 
        chkb1.AutoSize = True
        chkb1.Location = New Point(6, 18)
        chkb1.Margin = New Padding(2)
        chkb1.Name = "chkb1"
        chkb1.Size = New Size(132, 17)
        chkb1.TabIndex = 9
        chkb1.Text = "Choco Chip (RM30)"
        chkb1.UseVisualStyleBackColor = True
        ' 
        ' GroupBox1
        ' 
        GroupBox1.BackColor = Color.HotPink
        GroupBox1.Controls.Add(n4)
        GroupBox1.Controls.Add(n3)
        GroupBox1.Controls.Add(n2)
        GroupBox1.Controls.Add(n1)
        GroupBox1.Controls.Add(chkb4)
        GroupBox1.Controls.Add(chkb3)
        GroupBox1.Controls.Add(chkb2)
        GroupBox1.Controls.Add(chkb1)
        GroupBox1.Font = New Font("Arial", 8F, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Point, CByte(0))
        GroupBox1.Location = New Point(500, 114)
        GroupBox1.Margin = New Padding(2)
        GroupBox1.Name = "GroupBox1"
        GroupBox1.Padding = New Padding(2)
        GroupBox1.Size = New Size(214, 104)
        GroupBox1.TabIndex = 10
        GroupBox1.TabStop = False
        GroupBox1.Text = "HAVE YOUR COOKIES!!"
        ' 
        ' n4
        ' 
        n4.Location = New Point(169, 74)
        n4.Margin = New Padding(2)
        n4.Name = "n4"
        n4.Size = New Size(32, 20)
        n4.TabIndex = 16
        ' 
        ' n3
        ' 
        n3.Location = New Point(169, 55)
        n3.Margin = New Padding(2)
        n3.Name = "n3"
        n3.Size = New Size(32, 20)
        n3.TabIndex = 15
        ' 
        ' n2
        ' 
        n2.Location = New Point(169, 35)
        n2.Margin = New Padding(2)
        n2.Name = "n2"
        n2.Size = New Size(32, 20)
        n2.TabIndex = 14
        ' 
        ' n1
        ' 
        n1.Location = New Point(169, 16)
        n1.Margin = New Padding(2)
        n1.Name = "n1"
        n1.Size = New Size(32, 20)
        n1.TabIndex = 13
        ' 
        ' chkb4
        ' 
        chkb4.AutoSize = True
        chkb4.Location = New Point(6, 76)
        chkb4.Margin = New Padding(2)
        chkb4.Name = "chkb4"
        chkb4.Size = New Size(156, 17)
        chkb4.TabIndex = 12
        chkb4.Text = "Almond London (RM25)"
        chkb4.UseVisualStyleBackColor = True
        ' 
        ' chkb3
        ' 
        chkb3.AutoSize = True
        chkb3.Location = New Point(6, 55)
        chkb3.Margin = New Padding(2)
        chkb3.Name = "chkb3"
        chkb3.Size = New Size(144, 17)
        chkb3.TabIndex = 11
        chkb3.Text = "Peanut Butter (RM35)"
        chkb3.UseVisualStyleBackColor = True
        ' 
        ' chkb2
        ' 
        chkb2.AutoSize = True
        chkb2.Location = New Point(6, 35)
        chkb2.Margin = New Padding(2)
        chkb2.Name = "chkb2"
        chkb2.Size = New Size(118, 17)
        chkb2.TabIndex = 10
        chkb2.Text = "Macaron (RM40)"
        chkb2.UseVisualStyleBackColor = True
        ' 
        ' btnPay
        ' 
        btnPay.BackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        btnPay.Font = New Font("Showcard Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnPay.Location = New Point(483, 281)
        btnPay.Margin = New Padding(2)
        btnPay.Name = "btnPay"
        btnPay.Size = New Size(92, 35)
        btnPay.TabIndex = 11
        btnPay.Text = "PAY:"
        btnPay.UseVisualStyleBackColor = False
        ' 
        ' btnExit
        ' 
        btnExit.BackColor = Color.Fuchsia
        btnExit.Font = New Font("Showcard Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnExit.Location = New Point(622, 421)
        btnExit.Margin = New Padding(2)
        btnExit.Name = "btnExit"
        btnExit.Size = New Size(92, 35)
        btnExit.TabIndex = 12
        btnExit.Text = "EXIT"
        btnExit.UseVisualStyleBackColor = False
        ' 
        ' lblPrice
        ' 
        lblPrice.AutoSize = True
        lblPrice.BackColor = Color.Pink
        lblPrice.Font = New Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblPrice.Location = New Point(640, 253)
        lblPrice.Margin = New Padding(2, 0, 2, 0)
        lblPrice.Name = "lblPrice"
        lblPrice.Size = New Size(31, 15)
        lblPrice.TabIndex = 14
        lblPrice.Text = "0.00"
        ' 
        ' btnTotal
        ' 
        btnTotal.BackColor = Color.FromArgb(CByte(192), CByte(0), CByte(0))
        btnTotal.Font = New Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnTotal.Location = New Point(483, 241)
        btnTotal.Margin = New Padding(2)
        btnTotal.Name = "btnTotal"
        btnTotal.Size = New Size(136, 36)
        btnTotal.TabIndex = 15
        btnTotal.Text = "TOTAL PRICE (RM) :"
        btnTotal.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(738, 467)
        Controls.Add(btnTotal)
        Controls.Add(lblPrice)
        Controls.Add(btnExit)
        Controls.Add(btnPay)
        Controls.Add(GroupBox1)
        Controls.Add(Label5)
        Controls.Add(PictureBox4)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(lblTitle)
        Margin = New Padding(2)
        Name = "Form1"
        Text = "Main Page"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        GroupBox1.ResumeLayout(False)
        GroupBox1.PerformLayout()
        CType(n4, ComponentModel.ISupportInitialize).EndInit()
        CType(n3, ComponentModel.ISupportInitialize).EndInit()
        CType(n2, ComponentModel.ISupportInitialize).EndInit()
        CType(n1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents chkb1 As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkb3 As CheckBox
    Friend WithEvents chkb2 As CheckBox
    Friend WithEvents chkb4 As CheckBox
    Friend WithEvents n4 As NumericUpDown
    Friend WithEvents n3 As NumericUpDown
    Friend WithEvents n2 As NumericUpDown
    Friend WithEvents n1 As NumericUpDown
    Friend WithEvents btnPay As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblPrice As Label
    Friend WithEvents btnTotal As Button

End Class
