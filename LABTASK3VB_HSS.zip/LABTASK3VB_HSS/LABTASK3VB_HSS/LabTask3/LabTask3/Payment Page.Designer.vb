﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Payment_Page
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Payment_Page))
        lblPayment = New Label()
        Label2 = New Label()
        ImageList1 = New ImageList(components)
        ListBox1 = New ListBox()
        Label3 = New Label()
        Label4 = New Label()
        ComboBox1 = New ComboBox()
        ComboBox2 = New ComboBox()
        btnConfirm = New Button()
        btnHome = New Button()
        SuspendLayout()
        ' 
        ' lblPayment
        ' 
        lblPayment.AutoSize = True
        lblPayment.Font = New Font("Showcard Gothic", 9.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblPayment.Location = New Point(227, 18)
        lblPayment.Margin = New Padding(2, 0, 2, 0)
        lblPayment.Name = "lblPayment"
        lblPayment.Size = New Size(141, 17)
        lblPayment.TabIndex = 0
        lblPayment.Text = "PAYMENT DETAILS"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(11, 32)
        Label2.Margin = New Padding(2, 0, 2, 0)
        Label2.Name = "Label2"
        Label2.Size = New Size(0, 15)
        Label2.TabIndex = 1
        ' 
        ' ImageList1
        ' 
        ImageList1.ColorDepth = ColorDepth.Depth32Bit
        ImageList1.ImageSize = New Size(16, 16)
        ImageList1.TransparentColor = Color.Transparent
        ' 
        ' ListBox1
        ' 
        ListBox1.BackColor = Color.Orchid
        ListBox1.FormattingEnabled = True
        ListBox1.ItemHeight = 15
        ListBox1.Location = New Point(11, 56)
        ListBox1.Margin = New Padding(2)
        ListBox1.Name = "ListBox1"
        ListBox1.Size = New Size(246, 184)
        ListBox1.TabIndex = 2
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Salmon
        Label3.Font = New Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(291, 56)
        Label3.Margin = New Padding(2, 0, 2, 0)
        Label3.Name = "Label3"
        Label3.Size = New Size(117, 15)
        Label3.TabIndex = 3
        Label3.Text = "Type of Cookies :"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Salmon
        Label4.Font = New Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(291, 104)
        Label4.Margin = New Padding(2, 0, 2, 0)
        Label4.Name = "Label4"
        Label4.Size = New Size(104, 15)
        Label4.TabIndex = 4
        Label4.Text = "PAYMENT TYPE :"
        ' 
        ' ComboBox1
        ' 
        ComboBox1.BackColor = Color.LavenderBlush
        ComboBox1.FormattingEnabled = True
        ComboBox1.Items.AddRange(New Object() {"LARGE SIZE", "MEDIUM SIZE", "SMALL SIZE"})
        ComboBox1.Location = New Point(415, 53)
        ComboBox1.Margin = New Padding(2)
        ComboBox1.Name = "ComboBox1"
        ComboBox1.Size = New Size(129, 23)
        ComboBox1.TabIndex = 5
        ' 
        ' ComboBox2
        ' 
        ComboBox2.BackColor = Color.LavenderBlush
        ComboBox2.FormattingEnabled = True
        ComboBox2.Items.AddRange(New Object() {"ONLINE BANKING", "DELIVERY CHARGE"})
        ComboBox2.Location = New Point(415, 102)
        ComboBox2.Margin = New Padding(2)
        ComboBox2.Name = "ComboBox2"
        ComboBox2.Size = New Size(129, 23)
        ComboBox2.TabIndex = 6
        ' 
        ' btnConfirm
        ' 
        btnConfirm.Font = New Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnConfirm.Location = New Point(272, 180)
        btnConfirm.Margin = New Padding(2)
        btnConfirm.Name = "btnConfirm"
        btnConfirm.Size = New Size(136, 28)
        btnConfirm.TabIndex = 7
        btnConfirm.Text = "CONFIRM PAYMENT"
        btnConfirm.UseVisualStyleBackColor = True
        ' 
        ' btnHome
        ' 
        btnHome.Font = New Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnHome.Location = New Point(415, 180)
        btnHome.Margin = New Padding(2)
        btnHome.Name = "btnHome"
        btnHome.Size = New Size(136, 28)
        btnHome.TabIndex = 8
        btnHome.Text = "HOMEPAGE"
        btnHome.UseVisualStyleBackColor = True
        ' 
        ' Payment_Page
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = Color.Pink
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        ClientSize = New Size(560, 270)
        Controls.Add(btnHome)
        Controls.Add(btnConfirm)
        Controls.Add(ComboBox2)
        Controls.Add(ComboBox1)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(ListBox1)
        Controls.Add(Label2)
        Controls.Add(lblPayment)
        Margin = New Padding(2)
        Name = "Payment_Page"
        Text = "Payment Page"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblPayment As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents ImageList1 As ImageList
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents btnConfirm As Button
    Friend WithEvents btnHome As Button
End Class
