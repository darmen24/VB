﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.gbStudInfo = New System.Windows.Forms.GroupBox()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnTotal = New System.Windows.Forms.Button()
        Me.gbSecondarySchool = New System.Windows.Forms.GroupBox()
        Me.cbBio = New System.Windows.Forms.CheckBox()
        Me.cbChemistry = New System.Windows.Forms.CheckBox()
        Me.cbPhy = New System.Windows.Forms.CheckBox()
        Me.cbAddMath = New System.Windows.Forms.CheckBox()
        Me.cbSciSecondary = New System.Windows.Forms.CheckBox()
        Me.cbMathSecondary = New System.Windows.Forms.CheckBox()
        Me.cbEngSecondary = New System.Windows.Forms.CheckBox()
        Me.cbBmSecondary = New System.Windows.Forms.CheckBox()
        Me.gbPrimarySchool = New System.Windows.Forms.GroupBox()
        Me.cbScPrimary = New System.Windows.Forms.CheckBox()
        Me.cbMathPrimary = New System.Windows.Forms.CheckBox()
        Me.cbEngPrimary = New System.Windows.Forms.CheckBox()
        Me.cbBmPrimary = New System.Windows.Forms.CheckBox()
        Me.lblList = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.rbNo = New System.Windows.Forms.RadioButton()
        Me.rbYes = New System.Windows.Forms.RadioButton()
        Me.lblNewStud = New System.Windows.Forms.Label()
        Me.cbLevel = New System.Windows.Forms.ComboBox()
        Me.cbAge = New System.Windows.Forms.ComboBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.lblLevel = New System.Windows.Forms.Label()
        Me.lblAge = New System.Windows.Forms.Label()
        Me.lblBirthday = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.gbStudInfo.SuspendLayout()
        Me.gbSecondarySchool.SuspendLayout()
        Me.gbPrimarySchool.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(298, 32)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(243, 25)
        Me.lblTitle.TabIndex = 0
        Me.lblTitle.Text = "ABC TUITION CENTRE"
        '
        'gbStudInfo
        '
        Me.gbStudInfo.Controls.Add(Me.lblPrice)
        Me.gbStudInfo.Controls.Add(Me.btnBrowse)
        Me.gbStudInfo.Controls.Add(Me.btnSubmit)
        Me.gbStudInfo.Controls.Add(Me.btnTotal)
        Me.gbStudInfo.Controls.Add(Me.gbSecondarySchool)
        Me.gbStudInfo.Controls.Add(Me.gbPrimarySchool)
        Me.gbStudInfo.Controls.Add(Me.lblList)
        Me.gbStudInfo.Controls.Add(Me.PictureBox1)
        Me.gbStudInfo.Controls.Add(Me.rbNo)
        Me.gbStudInfo.Controls.Add(Me.rbYes)
        Me.gbStudInfo.Controls.Add(Me.lblNewStud)
        Me.gbStudInfo.Controls.Add(Me.cbLevel)
        Me.gbStudInfo.Controls.Add(Me.cbAge)
        Me.gbStudInfo.Controls.Add(Me.DateTimePicker1)
        Me.gbStudInfo.Controls.Add(Me.txtName)
        Me.gbStudInfo.Controls.Add(Me.lblLevel)
        Me.gbStudInfo.Controls.Add(Me.lblAge)
        Me.gbStudInfo.Controls.Add(Me.lblBirthday)
        Me.gbStudInfo.Controls.Add(Me.lblName)
        Me.gbStudInfo.Location = New System.Drawing.Point(64, 71)
        Me.gbStudInfo.Name = "gbStudInfo"
        Me.gbStudInfo.Size = New System.Drawing.Size(729, 510)
        Me.gbStudInfo.TabIndex = 1
        Me.gbStudInfo.TabStop = False
        Me.gbStudInfo.Text = "Student Info"
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.BackColor = System.Drawing.Color.AntiqueWhite
        Me.lblPrice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPrice.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrice.Location = New System.Drawing.Point(270, 459)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Padding = New System.Windows.Forms.Padding(40, 4, 40, 4)
        Me.lblPrice.Size = New System.Drawing.Size(126, 30)
        Me.lblPrice.TabIndex = 21
        Me.lblPrice.Text = "0.00"
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnBrowse
        '
        Me.btnBrowse.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBrowse.Location = New System.Drawing.Point(470, 172)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(187, 35)
        Me.btnBrowse.TabIndex = 20
        Me.btnBrowse.Text = "BROWSE"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSubmit.Location = New System.Drawing.Point(478, 453)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(203, 36)
        Me.btnSubmit.TabIndex = 19
        Me.btnSubmit.Text = "SUBMIT REGISTRATION"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnTotal
        '
        Me.btnTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTotal.Location = New System.Drawing.Point(43, 456)
        Me.btnTotal.Name = "btnTotal"
        Me.btnTotal.Size = New System.Drawing.Size(203, 36)
        Me.btnTotal.TabIndex = 16
        Me.btnTotal.Text = "TOTAL FEE (RM) :"
        Me.btnTotal.UseVisualStyleBackColor = True
        '
        'gbSecondarySchool
        '
        Me.gbSecondarySchool.Controls.Add(Me.cbBio)
        Me.gbSecondarySchool.Controls.Add(Me.cbChemistry)
        Me.gbSecondarySchool.Controls.Add(Me.cbPhy)
        Me.gbSecondarySchool.Controls.Add(Me.cbAddMath)
        Me.gbSecondarySchool.Controls.Add(Me.cbSciSecondary)
        Me.gbSecondarySchool.Controls.Add(Me.cbMathSecondary)
        Me.gbSecondarySchool.Controls.Add(Me.cbEngSecondary)
        Me.gbSecondarySchool.Controls.Add(Me.cbBmSecondary)
        Me.gbSecondarySchool.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbSecondarySchool.Location = New System.Drawing.Point(272, 278)
        Me.gbSecondarySchool.Name = "gbSecondarySchool"
        Me.gbSecondarySchool.Size = New System.Drawing.Size(451, 159)
        Me.gbSecondarySchool.TabIndex = 15
        Me.gbSecondarySchool.TabStop = False
        Me.gbSecondarySchool.Text = "Secondary School"
        '
        'cbBio
        '
        Me.cbBio.AutoSize = True
        Me.cbBio.Location = New System.Drawing.Point(246, 117)
        Me.cbBio.Name = "cbBio"
        Me.cbBio.Size = New System.Drawing.Size(159, 20)
        Me.cbBio.TabIndex = 7
        Me.cbBio.Text = "Biology (RM 75.00)"
        Me.cbBio.UseVisualStyleBackColor = True
        '
        'cbChemistry
        '
        Me.cbChemistry.AutoSize = True
        Me.cbChemistry.Location = New System.Drawing.Point(246, 88)
        Me.cbChemistry.Name = "cbChemistry"
        Me.cbChemistry.Size = New System.Drawing.Size(174, 20)
        Me.cbChemistry.TabIndex = 6
        Me.cbChemistry.Text = "Chemistry (RM 75.00)"
        Me.cbChemistry.UseVisualStyleBackColor = True
        '
        'cbPhy
        '
        Me.cbPhy.AutoSize = True
        Me.cbPhy.Location = New System.Drawing.Point(246, 58)
        Me.cbPhy.Name = "cbPhy"
        Me.cbPhy.Size = New System.Drawing.Size(160, 20)
        Me.cbPhy.TabIndex = 5
        Me.cbPhy.Text = "Physics (RM 75.00)"
        Me.cbPhy.UseVisualStyleBackColor = True
        '
        'cbAddMath
        '
        Me.cbAddMath.AutoSize = True
        Me.cbAddMath.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbAddMath.Location = New System.Drawing.Point(246, 29)
        Me.cbAddMath.Name = "cbAddMath"
        Me.cbAddMath.Size = New System.Drawing.Size(171, 20)
        Me.cbAddMath.TabIndex = 4
        Me.cbAddMath.Text = "Add Math (RM 75.00)"
        Me.cbAddMath.UseVisualStyleBackColor = True
        '
        'cbSciSecondary
        '
        Me.cbSciSecondary.AutoSize = True
        Me.cbSciSecondary.Location = New System.Drawing.Point(14, 117)
        Me.cbSciSecondary.Name = "cbSciSecondary"
        Me.cbSciSecondary.Size = New System.Drawing.Size(162, 20)
        Me.cbSciSecondary.TabIndex = 3
        Me.cbSciSecondary.Text = "Science (RM 55.00)"
        Me.cbSciSecondary.UseVisualStyleBackColor = True
        '
        'cbMathSecondary
        '
        Me.cbMathSecondary.AutoSize = True
        Me.cbMathSecondary.Location = New System.Drawing.Point(13, 88)
        Me.cbMathSecondary.Name = "cbMathSecondary"
        Me.cbMathSecondary.Size = New System.Drawing.Size(185, 20)
        Me.cbMathSecondary.TabIndex = 2
        Me.cbMathSecondary.Text = "Mathematic (RM 60.00)"
        Me.cbMathSecondary.UseVisualStyleBackColor = True
        '
        'cbEngSecondary
        '
        Me.cbEngSecondary.AutoSize = True
        Me.cbEngSecondary.Location = New System.Drawing.Point(13, 58)
        Me.cbEngSecondary.Name = "cbEngSecondary"
        Me.cbEngSecondary.Size = New System.Drawing.Size(157, 20)
        Me.cbEngSecondary.TabIndex = 1
        Me.cbEngSecondary.Text = "English (RM 45.00)"
        Me.cbEngSecondary.UseVisualStyleBackColor = True
        '
        'cbBmSecondary
        '
        Me.cbBmSecondary.AutoSize = True
        Me.cbBmSecondary.Location = New System.Drawing.Point(13, 30)
        Me.cbBmSecondary.Name = "cbBmSecondary"
        Me.cbBmSecondary.Size = New System.Drawing.Size(213, 20)
        Me.cbBmSecondary.TabIndex = 0
        Me.cbBmSecondary.Text = "Bahasa Melayu (RM 50.00)"
        Me.cbBmSecondary.UseVisualStyleBackColor = True
        '
        'gbPrimarySchool
        '
        Me.gbPrimarySchool.Controls.Add(Me.cbScPrimary)
        Me.gbPrimarySchool.Controls.Add(Me.cbMathPrimary)
        Me.gbPrimarySchool.Controls.Add(Me.cbEngPrimary)
        Me.gbPrimarySchool.Controls.Add(Me.cbBmPrimary)
        Me.gbPrimarySchool.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbPrimarySchool.Location = New System.Drawing.Point(16, 278)
        Me.gbPrimarySchool.Name = "gbPrimarySchool"
        Me.gbPrimarySchool.Size = New System.Drawing.Size(248, 159)
        Me.gbPrimarySchool.TabIndex = 14
        Me.gbPrimarySchool.TabStop = False
        Me.gbPrimarySchool.Text = "Primary School"
        '
        'cbScPrimary
        '
        Me.cbScPrimary.AutoSize = True
        Me.cbScPrimary.Location = New System.Drawing.Point(9, 116)
        Me.cbScPrimary.Name = "cbScPrimary"
        Me.cbScPrimary.Size = New System.Drawing.Size(162, 20)
        Me.cbScPrimary.TabIndex = 3
        Me.cbScPrimary.Text = "Science (RM 55.00)"
        Me.cbScPrimary.UseVisualStyleBackColor = True
        '
        'cbMathPrimary
        '
        Me.cbMathPrimary.AutoSize = True
        Me.cbMathPrimary.Location = New System.Drawing.Point(9, 87)
        Me.cbMathPrimary.Name = "cbMathPrimary"
        Me.cbMathPrimary.Size = New System.Drawing.Size(185, 20)
        Me.cbMathPrimary.TabIndex = 2
        Me.cbMathPrimary.Text = "Mathematic (RM 60.00)"
        Me.cbMathPrimary.UseVisualStyleBackColor = True
        '
        'cbEngPrimary
        '
        Me.cbEngPrimary.AutoSize = True
        Me.cbEngPrimary.Location = New System.Drawing.Point(9, 57)
        Me.cbEngPrimary.Name = "cbEngPrimary"
        Me.cbEngPrimary.Size = New System.Drawing.Size(157, 20)
        Me.cbEngPrimary.TabIndex = 1
        Me.cbEngPrimary.Text = "English (RM 45.00)"
        Me.cbEngPrimary.UseVisualStyleBackColor = True
        '
        'cbBmPrimary
        '
        Me.cbBmPrimary.AutoSize = True
        Me.cbBmPrimary.Location = New System.Drawing.Point(9, 29)
        Me.cbBmPrimary.Name = "cbBmPrimary"
        Me.cbBmPrimary.Size = New System.Drawing.Size(213, 20)
        Me.cbBmPrimary.TabIndex = 0
        Me.cbBmPrimary.Text = "Bahasa Melayu (RM 45.00)"
        Me.cbBmPrimary.UseVisualStyleBackColor = True
        '
        'lblList
        '
        Me.lblList.AutoSize = True
        Me.lblList.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.lblList.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblList.Location = New System.Drawing.Point(24, 233)
        Me.lblList.Name = "lblList"
        Me.lblList.Padding = New System.Windows.Forms.Padding(275, 5, 275, 5)
        Me.lblList.Size = New System.Drawing.Size(682, 30)
        Me.lblList.TabIndex = 13
        Me.lblList.Text = "List of Subject"
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Location = New System.Drawing.Point(470, 27)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(187, 139)
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'rbNo
        '
        Me.rbNo.AutoSize = True
        Me.rbNo.Location = New System.Drawing.Point(263, 189)
        Me.rbNo.Name = "rbNo"
        Me.rbNo.Size = New System.Drawing.Size(46, 20)
        Me.rbNo.TabIndex = 11
        Me.rbNo.TabStop = True
        Me.rbNo.Text = "No"
        Me.rbNo.UseVisualStyleBackColor = True
        '
        'rbYes
        '
        Me.rbYes.AutoSize = True
        Me.rbYes.Location = New System.Drawing.Point(164, 189)
        Me.rbYes.Name = "rbYes"
        Me.rbYes.Size = New System.Drawing.Size(52, 20)
        Me.rbYes.TabIndex = 10
        Me.rbYes.TabStop = True
        Me.rbYes.Text = "Yes"
        Me.rbYes.UseVisualStyleBackColor = True
        '
        'lblNewStud
        '
        Me.lblNewStud.AutoSize = True
        Me.lblNewStud.Location = New System.Drawing.Point(40, 191)
        Me.lblNewStud.Name = "lblNewStud"
        Me.lblNewStud.Size = New System.Drawing.Size(88, 16)
        Me.lblNewStud.TabIndex = 9
        Me.lblNewStud.Text = "New Student :"
        '
        'cbLevel
        '
        Me.cbLevel.FormattingEnabled = True
        Me.cbLevel.Items.AddRange(New Object() {"Primary School", "Secondary School"})
        Me.cbLevel.Location = New System.Drawing.Point(159, 147)
        Me.cbLevel.Name = "cbLevel"
        Me.cbLevel.Size = New System.Drawing.Size(153, 24)
        Me.cbLevel.TabIndex = 8
        Me.cbLevel.Text = "Select One"
        '
        'cbAge
        '
        Me.cbAge.FormattingEnabled = True
        Me.cbAge.Items.AddRange(New Object() {"7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18"})
        Me.cbAge.Location = New System.Drawing.Point(159, 107)
        Me.cbAge.Name = "cbAge"
        Me.cbAge.Size = New System.Drawing.Size(153, 24)
        Me.cbAge.TabIndex = 7
        Me.cbAge.Text = "Select One"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(159, 67)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(242, 22)
        Me.DateTimePicker1.TabIndex = 6
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(159, 27)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(242, 22)
        Me.txtName.TabIndex = 4
        '
        'lblLevel
        '
        Me.lblLevel.AutoSize = True
        Me.lblLevel.Location = New System.Drawing.Point(23, 153)
        Me.lblLevel.Name = "lblLevel"
        Me.lblLevel.Size = New System.Drawing.Size(105, 16)
        Me.lblLevel.TabIndex = 3
        Me.lblLevel.Text = "Level of School :"
        '
        'lblAge
        '
        Me.lblAge.AutoSize = True
        Me.lblAge.Location = New System.Drawing.Point(90, 114)
        Me.lblAge.Name = "lblAge"
        Me.lblAge.Size = New System.Drawing.Size(38, 16)
        Me.lblAge.TabIndex = 2
        Me.lblAge.Text = "Age :"
        '
        'lblBirthday
        '
        Me.lblBirthday.AutoSize = True
        Me.lblBirthday.Location = New System.Drawing.Point(43, 73)
        Me.lblBirthday.Name = "lblBirthday"
        Me.lblBirthday.Size = New System.Drawing.Size(85, 16)
        Me.lblBirthday.TabIndex = 1
        Me.lblBirthday.Text = "Date of Birth :"
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(78, 33)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(50, 16)
        Me.lblName.TabIndex = 0
        Me.lblName.Text = "Name :"
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(805, 594)
        Me.Controls.Add(Me.gbStudInfo)
        Me.Controls.Add(Me.lblTitle)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.gbStudInfo.ResumeLayout(False)
        Me.gbStudInfo.PerformLayout()
        Me.gbSecondarySchool.ResumeLayout(False)
        Me.gbSecondarySchool.PerformLayout()
        Me.gbPrimarySchool.ResumeLayout(False)
        Me.gbPrimarySchool.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents gbStudInfo As GroupBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents txtName As TextBox
    Friend WithEvents lblLevel As Label
    Friend WithEvents lblAge As Label
    Friend WithEvents lblBirthday As Label
    Friend WithEvents lblName As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents rbNo As RadioButton
    Friend WithEvents rbYes As RadioButton
    Friend WithEvents lblNewStud As Label
    Friend WithEvents cbLevel As ComboBox
    Friend WithEvents cbAge As ComboBox
    Friend WithEvents lblList As Label
    Friend WithEvents gbPrimarySchool As GroupBox
    Friend WithEvents cbScPrimary As CheckBox
    Friend WithEvents cbMathPrimary As CheckBox
    Friend WithEvents cbEngPrimary As CheckBox
    Friend WithEvents cbBmPrimary As CheckBox
    Friend WithEvents gbSecondarySchool As GroupBox
    Friend WithEvents cbBio As CheckBox
    Friend WithEvents cbChemistry As CheckBox
    Friend WithEvents cbPhy As CheckBox
    Friend WithEvents cbAddMath As CheckBox
    Friend WithEvents cbSciSecondary As CheckBox
    Friend WithEvents cbMathSecondary As CheckBox
    Friend WithEvents cbEngSecondary As CheckBox
    Friend WithEvents cbBmSecondary As CheckBox
    Friend WithEvents btnTotal As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnBrowse As Button
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents lblPrice As Label
End Class
