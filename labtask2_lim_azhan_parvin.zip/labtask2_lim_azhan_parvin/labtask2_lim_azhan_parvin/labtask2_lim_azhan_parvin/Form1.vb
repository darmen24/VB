﻿Public Class Form1
    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        OpenFileDialog1.Title = "Please select a picture of a student"
        OpenFileDialog1.InitialDirectory = "C:\"
        OpenFileDialog1.Filter = "Image Files|*.ico;*.jpg;*.bmp;*.gif;*.png"

        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Try
                PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
                PictureBox1.Image = Image.FromFile(OpenFileDialog1.FileName)
            Catch ex As Exception
                MessageBox.Show("Error loading the image: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Variable declaration 
        Dim PrimBM As Double = 45
        Dim PrimBI As Double = 45
        Dim PrimMATH As Double = 65
        Dim PrimSC As Double = 55
        Dim SecondBM As Double = 50
        Dim SecondBI As Double = 50
        Dim SecondMATH As Double = 65
        Dim SecondSC As Double = 60
        Dim SecondADDMATH As Double = 75
        Dim SecondPHY As Double = 75
        Dim SecondCHEMI As Double = 75
        Dim SecondBIO As Double = 75
        Dim Total As Double

        'If checkbox is checked,and calculation
        'prim school
        If cbBmPrimary.Checked = True Then
            Total += PrimBM
        End If

        If cbEngPrimary.Checked = True Then
            Total += PrimBI
        End If

        If cbMathPrimary.Checked = True Then
            Total += PrimMATH
        End If

        If cbScPrimary.Checked = True Then
            Total += PrimSC
        End If

        'second school
        If cbBmSecondary.Checked = True Then
            Total += SecondBM
        End If

        If cbEngSecondary.Checked = True Then
            Total += SecondBI
        End If

        If cbMathSecondary.Checked = True Then
            Total += SecondMATH
        End If

        If cbSciSecondary.Checked = True Then
            Total += SecondSC
        End If

        If cbAddMath.Checked = True Then
            Total += SecondADDMATH
        End If

        If cbPhy.Checked = True Then
            Total += SecondPHY
        End If

        If cbChemistry.Checked = True Then
            Total += SecondCHEMI
        End If

        If cbBio.Checked = True Then
            Total += SecondBIO
        End If

        ' Round off to 2 decimal places
        Total = Math.Round(Total, 2)

        MessageBox.Show("Are you sure to register", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)

        If rbNo.Checked Then
            Dim discount As Double = 0.05
            Total *= (1 - discount)

        End If

        '  2 decimal places
        lblPrice.Text = "RM" & Total.ToString("F2")

    End Sub

    Private Sub rbNo_CheckedChanged(sender As Object, e As EventArgs) Handles rbNo.CheckedChanged
        Dim OldStudent As Boolean = rbNo.Checked

        If OldStudent Then
            MessageBox.Show("You are a long-standing member.You are entitled to a 5% fee discount.", "Congratulations !!!", MessageBoxButtons.OK)
        End If
    End Sub


End Class
